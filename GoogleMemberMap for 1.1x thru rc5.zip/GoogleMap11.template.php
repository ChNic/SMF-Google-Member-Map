<?php
// Google Maps Mod
// by
// TLM --- Taken Over By brianjw <brianjw@verizon.net>

function template_map() {
	global $context, $modSettings, $scripturl, $txt, $settings;

	if ($modSettings['googleMapsEnable']) {
echo '   <table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td width="100%" align="left" valign="top" style="padding-top: 10px; padding-bottom: 10px;"><style type="text/css"><!--
/* Google Maps */
.googleMaps
{
	
	font-size: small;
	font-family: tahoma, sans-serif;
}
.googleMapsSidebar
{
    
    font-size: x-small;
    font-family: tahoma, sans-serif;
    margin: 0px;
    
    overflow: auto;
    width: 150px;
    height: 500px;
}
.googleMapsLegend
{
    
    font-size: x-small;
    font-family: tahoma, sans-serif;
    margin: 0px;
    
    overflow: auto;
}
/* Google Maps Links */
a.googleMapsLink:link, a.googleMapsLink:visited, a.googleMapsLink:hover
{
	
	font-size: small;
	font-family: tahoma, sans-serif;
}
/* THEME EDITS
#map a:link{
    color: #000080;
}
#map a{
    color: #00ff00;
}

#map a:active{
    color: #ff0000;
}

#map a:hover{
    color: #000;
}
*/
--></style><div class="tborder" style="margin-top: 1ex;">
		<div id="googlemap" class="titlebg" style="padding: 4px;">', $txt['googleMap'], '</div>
		<div id="googlemapmain" class="windowbg2">
	<table width="100%">
    <tr>
		<td class="windowbg2" colspan="2" valign="middle" align="center">
            <table>
                <tr>
                    <td colspan="2" align="center">
                        <table><tr><td align="center">
                            <div id="map" onmousewheel="cancelscroll()" style="width: 675px; height: 500px; color: #000000;"></div>
                        ', $txt['googleMapc'], '</td>';
if (isset($modSettings['googleSidebar']) && $modSettings['googleSidebar'] == 1)
echo '
           <td align="center" style="whitespace: norwap;"><h3 ><em>', $txt['googleMappinned'], '</em></h3><hr style="width: 94%;"  />
                            <div id="sidebar" class="googleMapsSidebar" align="left" style="padding-left: 15px;"></div>
                        </td>';
if (isset($modSettings['googleSidebar']) && $modSettings['googleSidebar'] == 2)
echo '
                        </tr><tr>
                        <td align="center">
                            <div id="sidebar" class="googleMapsLegend" align="left"></div>
                        </td>';
echo '
                        </tr></table>
                        <script src="http://maps.google.com/maps?file=api&v=2&key=', $modSettings['googleMapsKey'], '" type="text/javascript"></script>
                        <script type="text/javascript" language="JavaScript" src="', $settings['default_theme_url'], '/Clusterer2.js"></script>
                        <script type="text/javascript" language="JavaScript" src="', $scripturl, '?action=googlemap;sa=.js"></script>
                    </td>';
if ($modSettings['googleMapsEnableLegend']) {
echo '
                </tr><tr>
                    <td colspan="2" align="center" class="googleMapsLegend">
                        <table><tr>';
if (!$modSettings['googleMapsPinGender'])
    echo '
                    <td><img src="http://labs.google.com/ridefinder/images/mm_20_green.png">', $txt['googleMapGreenPinGD'], '</td>';
else
    echo '
                        <td><img src="http://labs.google.com/ridefinder/images/mm_20_green.png">', $txt['googleMapGreenPinNG'], '</td>
                        <td><img src="http://labs.google.com/ridefinder/images/mm_20_blue.png">', $txt['googleMapBluePin'], '</td>
                        <td><img src="http://labs.google.com/ridefinder/images/mm_20_red.png">', $txt['googleMapRedPin'], '</td>';
if ($modSettings['googleMapsEnableClusterer'])
echo '
                        <td><img src="http://labs.google.com/ridefinder/images/mm_20_purple.png">', $txt['googleMapPurplePin'], '</td>';
echo '
                        </tr></table>
                    </td>';
}
echo '
                </tr><tr>
                    <td align="left">';
if (allowedTo('googleMap_place'))
    echo $txt['googleMapAddPinNote'];
echo '
                    </td>';
					if (!empty($modSettings['KMLoutput_enable']))
					echo '<td align="right">
                        <a href="', $scripturl, '?action=.kml"><img src="', $settings['default_theme_url'], '/images/google_earth_feed.gif" border="0" /></a>
                    </td>';
					echo '
                </tr>
            </table>
        </td>
	</tr></table>
        </div>
    </div></td></tr></table>';
    }
}

?>
