Google Member Map

COMPATIBLE WITH SMF 1.1.X AND SMF 2.0 RC3/RC4/RC5

Introduction
This mod installs a member map to your website which allows your members to pin their location on a map. It uses Google Maps API to generate the map and place 'Push" pins. Before installing it is recommended to make a backup of your member and settings tables for your forum. Once installed you will need to go to Features and Options (for SMF 1.1) or  Configuration -> Modification Settings -> Member Map (for SMP 2.0) to enable it and enter a google map API key for use on the forum. The key is required by the Google Maps, and can be acquired at for free at http://www.google.com/apis/maps/signup.html

Upon sign up you will need to enter your sites URL, for example, if your Forum is at http://www.example.com/forums/
In the google map sign up box enter exactly that, do not include any additional file name, just the directory path in the url.

Live Demo: http://www.bluedevilcustoms.com/index.php?action=googlemap

Please report any & all bugs you find, no matter how trivial. Remember to backup your database AND files before installing any modifications.

Installation
Simply install this package through the package manager located in your Administration Panel. Manual edits may be required if your site uses a custom theme.

How Do I Use This Mod?
In your admin panel you will need to enable it and enter your google map API key to allow it to function correctly. Next, your members will need to edit their profiles and place a pin on the map to show their location and save their profile. That pin will then display on the main member map page. The admin will also need to set the map permissions so users can see and use it. 

Changelog
2.08
! fixed undefined index error in the googlemap20 template
+ updated the template html code to remove several unneeded tables
! removed several xhtml validation errors

2.07
! fixed error where setting maximum visible pins to zero should have been unlimited and was in fact really zero
+ updated some of the language txt strings to improve readability
+ RC5 Support

2.06c
! fixed issue where during the install the txt strings were being written in to the target files twice
2.06b
! fixed missing text name caused by 2.06 googleMapsPinrForeground change
! fixed admin panel so it can accept the hex color numbers, was cast as int only
+ small change to the .css file
2.06a
! fixed sidebar right/none mixup caused by moving of txt strings
! fixed looking for lower case css file while saving it as a camel case file

2.06
These changes are ONLY for the 2.0 branch, the 1.1x branch has not been updated 
! Moved additional text strings to language files
! Gender pin will follow the user pin setting of plain or icon, originally was fixed to icon only
! Fixed some spelling
! Fixed incorrect variable googleMapsPinrForeground, should have been googleMapsPinForeground

2.05
These changes are ONLY for the 2.0 branch, the 1.1x branch has not been updated 
! Fixed 0,0 issue where members could not remove a pin they had set
+ Map control (pan / zoom) style is now selectable
! Moved map pin graphic source from defunct goggle service to goggle charts
+ Admin controls for Pin size, Pin color, Plain, Text and icon pins & Drop Shadows (member and cluster pins)
+ Option to see the latest pin adds/moves in the sidebar
! Fixed template layouts to use curve style in more places
! Member Map location will appear under profile summary if they have set a pin and disappear if they remove their pin
+ Added additional information to the map pin info pop-up, webpage, email, pm
+ updated the install to use proper 2.0 database code, separate language files.
+ separated the style sheet to its own file vs in line
+ Improved integration with profile pages so it matches the page style (dd/dt)
+ Added total count of pins to the map page
- Removed global requirements from language file
- Removed defunct package server from install
+ Consolidated the 1.1x & 2.0 installs into a single package

1.0 Current
! fixed error where setting maximum visible pins to zero should have been unlimited and was in fact really zero

1.0 BETA 4
o ! Changed some hard coded text for this mod into language strings. This will now allow you to change that text in to your own language.
o ! New Feature didn't work all the way in the last version.
o ! Undefined Index error to $scripturl in Modifications.english.php
o ! Undefined sidbar error GoogleMap.php

1.0 BETA 3
o ! In 1.1.X version, some text wasn't put in the profile as a language string and was hard-coded.
o ! In All Versions, undefined index errors showing in error log for googleSidebar
o + Easier link to Google Member Map (place pin location). Just go to: http://www.yoursite.com/index.php?action=profile;sa=forumProfile#googlemap

1.0 BETA 2
o ! Internet Explorer bugs, some were experiencing.
o + search function to the add pin map in the profile for easier pin placing and easier finding locations.
o + option to display or to not display the KML feature. (For better security)
o ! CSS Should Be Fixed and the balloons on the map should be fixed for darker themes!
o + mouse-wheel zoom function to the map. You can now zoom using your mouse-wheel.
o - The frame view on the bottom left. (annoying and requested to be removed by many members)
o ? There is plenty more and you will find them.

0.1 BETA
o Mod taken over by brianjw, with TLM's permission.
o Supports 1.1, 1.1.1, 1.1.2, 1.1.3, 1.1.4, and 1.1.5.
o ! bugs from Previous Versions.
o + a new layout to the map made by StormLrd, see it on your website by selecting "Sidebar Right" in the admin. 

[b]All Previous Versions by TLM[/b]
o All past versions by TLM
o These are no longer supported.