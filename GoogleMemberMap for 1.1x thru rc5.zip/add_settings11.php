<?php
/*******************************************************************************
	This is a simplified script to add settings into SMF.

	ATTENTION: If you are trying to INSTALL this package, please access
	it directly, with a URL like the following:
		http://www.yourdomain.tld/forum/add_settings.php (or similar.)

================================================================================

	This script can be used to add new settings into the database for use
	with SMF's $modSettings array.  It is meant to be run either from the
	package manager or directly by URL.

*******************************************************************************/

// Set the below to true to overwrite already existing settings with the defaults. (not recommended.)
$overwrite_old_settings = false;

// List settings here in the format: setting_key => default_value.  Escape any "s. (" => \")
$mod_settings = array(
	'googleMapsEnable' => '0',
	'googleMapsEnableLegend' => '1',
	'googleMapsKey' => '',
	'googleMapsPinGender' => '1',
	'KMLoutput_enable' => '0',
	'googleMapsPinNumber' => '250',
    'googleMapsType' => 'G_HYBRID_TYPE',
    'googleMapsDefaultLat' => '0.00000000000',
    'googleMapsDefaultLong' => '0.00000000000',
    'googleMapsDefaultZoom' => '1',
    'googleMapsEnableClusterer' => '1',
    'googleMapsMinMarkerCluster' => '5',
    'googleMapsMaxVisMarker' => '150',
    'googleMapsMaxNumClusters' => '5',
    'googleMapsMaxLinesCluster' => '10',
);

/******************************************************************************/

// If SSI.php is in the same place as this file, and SMF isn't defined, this is being run standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

// Turn the array defined above into a string of MySQL data.
$string = '';
foreach ($mod_settings as $k => $v)
	$string .= '
			(\'' . $k . '\', \'' . $v . '\'),';

// Sorted out the array defined above - now insert the data!
if ($string != '')
	$result = db_query("
		" . ($overwrite_old_settings ? 'REPLACE' : 'INSERT IGNORE') . " INTO {$db_prefix}settings
			(variable, value)
		VALUES" . substr($string, 0, -1), __FILE__, __LINE__);

// Uh-oh spaghetti-oh!
if ($result === false)
	echo '<b>Error:</b> Database modifications failed!';

//Ok now the above is done... lets see if we can alter the members table to contain latitude and longitude
//First though, lets check to see if we are in need of to do this
$latlongexist = 0;
$result = db_query("SHOW COLUMNS FROM {$db_prefix}members", __FILE__, __LINE__);
while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
	if (($row['Field'] == "longitude") && ($row['Type'] == "decimal(18,15)") && ($row['Null'] == "YES"))
		$latlongexist++;
	if (($row['Field'] == "latitude") && ($row['Type'] == "decimal(18,15)") && ($row['Null'] == "YES"))
		$latlongexist++;
}
//Ok we just checked the table the hard way and well if 2 we have things, if 0 we dont, if 1 wtf....
if ($latlongexist != 2)
	$result = db_query("ALTER TABLE {$db_prefix}members ADD longitude DECIMAL( 18, 15 ) NULL , ADD latitude DECIMAL( 18, 15 ) NULL", __FILE__, __LINE__);
	
	// Initialize the groups array with 'ungrouped members' (ID: 0).
	$groups = array(0);

	// Get all the non-postcount based groups.
	$request = db_query("
		SELECT ID_GROUP
		FROM {$db_prefix}membergroups
		WHERE minPosts = -1", __FILE__, __LINE__);
	while ($row = mysql_fetch_assoc($request))
		$groups[] = $row['ID_GROUP'];

	// Give them all their new permission.
	$request = db_query("
		INSERT IGNORE INTO {$db_prefix}permissions
			(permission, ID_GROUP, addDeny)
		VALUES
			('googleMap_view', " . implode(", 1),
            ('googleMap_view', ", $groups) . ", 1)", __FILE__, __LINE__);

   	// Give them all their new permission.
	$request = db_query("
		INSERT IGNORE INTO {$db_prefix}permissions
			(permission, ID_GROUP, addDeny)
		VALUES
			('googleMap_place', " . implode(", 1),
            ('googleMap_place', ", $groups) . ", 1)", __FILE__, __LINE__);

   // Delete our package server if there is one.
   $request = db_query("
       DELETE FROM {$db_prefix}package_servers WHERE name = 'Gamerz Garage'", __FILE__, __LINE__);
      
   // Install our package server.
   $request = db_query("
      INSERT INTO {$db_prefix}package_servers (name,url)VALUES('Gamerz Garage','http://www.gamerzgarage.com/mods')", __FILE__, __LINE__);

?>
